package com.dao;

import java.util.Map;

import com.model.Student;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,Student> studentMap = StudentEnum.instance.getStudentsByClass();
		System.out.println("studentMap >> "+studentMap);
	}

}
