package com.dao;

import java.util.HashMap;
import java.util.Map;

import com.model.Student;

public enum StudentEnum {
	instance;
	
	public Map<String,Student> getStudentsByClass() {
		Map<String,Student> studentMap	= new HashMap<String,Student>();
		Student objStudent1	= new Student();
		objStudent1.setStudentName("Ajay");
		objStudent1.setStudentId("STD01");
		objStudent1.setStudentClass("10th");
		objStudent1.setStudentTotalMarks(80.00f);
		studentMap.put("STD01", objStudent1);
		
		Student objStudent2			= new Student();
		objStudent2.setStudentName("Tom");
		objStudent2.setStudentId("STD02");
		objStudent2.setStudentClass("8th");
		objStudent2.setStudentTotalMarks(90.00f);
		studentMap.put("STD02", objStudent2);
		
		Student objStudent3			= new Student();
		objStudent3.setStudentName("Ranbir");
		objStudent3.setStudentId("STD03");
		objStudent3.setStudentClass("7th");
		objStudent3.setStudentTotalMarks(60.00f);
		studentMap.put("STD03", objStudent3);
		
		Student objStudent4			= new Student();
		objStudent4.setStudentName("Sidhart");
		objStudent4.setStudentId("STD04");
		objStudent4.setStudentClass("6th");
		objStudent4.setStudentTotalMarks(70.00f);
		studentMap.put("STD04", objStudent4);
		
		Student objStudent5			= new Student();
		objStudent5.setStudentName("Krish");
		objStudent5.setStudentId("STD05");
		objStudent5.setStudentClass("9th");
		objStudent5.setStudentTotalMarks(50.00f);
		studentMap.put("STD05", objStudent5);
		
		return studentMap;
	}
}
