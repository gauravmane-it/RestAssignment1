package com.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.model.Student;

public class StudentDao {
	Map <String, Student> studentMap = null;
	List<Student> studentList	= null;
	public List<Student> getStudents() {
		studentList			= new ArrayList<Student>();
		studentMap			= new HashMap<String,Student>();
		Student objStudent1	= new Student();
		objStudent1.setStudentName("Ajay");
		objStudent1.setStudentId("STD01");
		objStudent1.setStudentClass("10th");
		objStudent1.setStudentTotalMarks(80.00f);
		studentMap.put("STD01", objStudent1);
		studentList.add(objStudent1);
		
		Student objStudent2			= new Student();
		objStudent2.setStudentName("Tom");
		objStudent2.setStudentId("STD02");
		objStudent2.setStudentClass("8th");
		objStudent2.setStudentTotalMarks(90.00f);
		studentMap.put("STD02", objStudent2);
		studentList.add(objStudent2);
		
		Student objStudent3			= new Student();
		objStudent3.setStudentName("Ranbir");
		objStudent3.setStudentId("STD03");
		objStudent3.setStudentClass("7th");
		objStudent3.setStudentTotalMarks(60.00f);
		studentMap.put("STD03", objStudent3);
		studentList.add(objStudent3);
		
		Student objStudent4			= new Student();
		objStudent4.setStudentName("Sidhart");
		objStudent4.setStudentId("STD04");
		objStudent4.setStudentClass("6th");
		objStudent4.setStudentTotalMarks(70.00f);
		studentMap.put("STD04", objStudent4);
		studentList.add(objStudent4);
		
		Student objStudent5			= new Student();
		objStudent5.setStudentName("Krish");
		objStudent5.setStudentId("STD05");
		objStudent5.setStudentClass("9th");
		objStudent5.setStudentTotalMarks(50.00f);
		studentMap.put("STD05", objStudent5);
		studentList.add(objStudent5);
		
		Student objStudent6			= new Student();
		objStudent6.setStudentName("Krish");
		objStudent6.setStudentId("STD06");
		objStudent6.setStudentClass("9th");
		objStudent6.setStudentTotalMarks(50.00f);
		studentMap.put("STD06", objStudent6);
		studentList.add(objStudent6);
		
		Student objStudent7			= new Student();
		objStudent7.setStudentName("Krish");
		objStudent7.setStudentId("STD07");
		objStudent7.setStudentClass("10th");
		objStudent7.setStudentTotalMarks(50.00f);
		studentMap.put("STD07", objStudent7);
		studentList.add(objStudent7);
		
		return studentList;
	}
	public Student getStudentsById(String id) {
		getStudents();
		return studentMap.get(id);
	}
	
	public List<Student> getGreaterThanMarks(float mark) {
		List<Student> studentList    = getStudents();
		List<Student> newStudentList = new ArrayList<Student>();
		int i = 0;
		for(Student std : studentList) {
			if(std.getStudentTotalMarks() > mark) {
				newStudentList.add(std);
			}
		}
		return newStudentList;
	}
	
	public Map <String, Student> addStudent(Student newStd) {
		getStudents();
		studentMap.put(newStd.getStudentId(), newStd);
		studentList.add(newStd);
		return studentMap;
	}
	
	public String deleteStudent(String id) {
		String statusMessage = null;
		boolean status = studentMap.containsKey(id) ? true : false;
		if(status) {
			statusMessage = "Student Deleted Successfully";
		} else {
			statusMessage = "Student Does not exists";
		}
		return statusMessage;
	}
	
	public List<Student> getStudentByClass(String stdClass) {
		List<Student> stdList = new ArrayList<Student>();
		for(Student std : getStudents()) {
			if(stdClass.equalsIgnoreCase(std.getStudentClass())) {
				stdList.add(std);
			}
		}
		return stdList;
	}
}
