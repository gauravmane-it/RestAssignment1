package com.resources;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.model.Movie;

@Path("/movie")
public class MovieResource {
	Map<String, Movie> movieMap = null;
	@GET
	@Produces(MediaType.TEXT_XML)
	public List<Movie> getMoviesList() {
		return getMovies();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	@Path("/inXML")
	public List<Movie> getMoviesListXML() {
		return getMovies();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/inJSON")
	public List<Movie> getMoviesListJson() {
		return getMovies();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	@Path("{Byid}")
	public Movie getMoviesByIdJson(@PathParam("Byid") String id) {
		getMovies();
		return movieMap.get(id);
	}
	
	@DELETE
	@Produces(MediaType.APPLICATION_XML)
	@Path("{Byid}")
	public String deleteMovieByIdJson(@PathParam("Byid") String id) {
		getMovies();
		movieMap.remove(id);
		return "Deleted";
	}
	
	public List<Movie> getMovies() {
		List<Movie>	movieList  	= new ArrayList<Movie>();
		movieMap				= new HashMap<String,Movie>();
		Movie objMovie1			= new Movie();
		objMovie1.setMovieName("TanhaJi");
		objMovie1.setMovieId("MO1");
		objMovie1.setMovieActor("Ajay Devgan");
		objMovie1.setMovieCollection(100.00f);
		movieMap.put("MO1", objMovie1);
		movieList.add(objMovie1);
		
		Movie objMovie2			= new Movie();
		objMovie2.setMovieName("TopGun");
		objMovie2.setMovieId("MO2");
		objMovie2.setMovieActor("TomCruise");
		objMovie2.setMovieCollection(50.00f);
		movieMap.put("MO2", objMovie2);
		movieList.add(objMovie2);
		
		Movie objMovie3			= new Movie();
		objMovie3.setMovieName("BajiRao Mastani");
		objMovie3.setMovieId("MO3");
		objMovie3.setMovieActor("Ranbir Singh");
		objMovie3.setMovieCollection(60.00f);
		movieMap.put("MO3", objMovie3);
		movieList.add(objMovie3);
		
		Movie objMovie4			= new Movie();
		objMovie4.setMovieName("Ashiqui");
		objMovie4.setMovieId("MO4");
		objMovie4.setMovieActor("Sidhart");
		objMovie4.setMovieCollection(70.00f);
		movieMap.put("M4", objMovie4);
		movieList.add(objMovie4);
		
		Movie objMovie5			= new Movie();
		objMovie5.setMovieName("Krish");
		objMovie5.setMovieId("MO5");
		objMovie5.setMovieActor("Hritik Roshan");
		objMovie5.setMovieCollection(50.00f);
		movieMap.put("MO5", objMovie5);
		movieList.add(objMovie5);
		
		Movie objMovie6			= new Movie();
		objMovie6.setMovieName("Kesari");
		objMovie6.setMovieId("MO6");
		objMovie6.setMovieActor("Akshay Kumar");
		objMovie6.setMovieCollection(80.00f);
		movieMap.put("MO6", objMovie6);
		movieList.add(objMovie6);
		
		Movie objMovie7			= new Movie();
		objMovie7.setMovieName("Barfi");
		objMovie7.setMovieId("MO7");
		objMovie7.setMovieActor("Ranveer Kapoor");
		objMovie7.setMovieCollection(90.00f);
		movieMap.put("MO7", objMovie7);
		movieList.add(objMovie7);
		
		Movie objMovie8			= new Movie();
		objMovie8.setMovieName("Agnipath");
		objMovie8.setMovieId("MO8");
		objMovie8.setMovieActor("Amitabh Bachchan");
		objMovie8.setMovieCollection(100.00f);
		movieMap.put("MO8", objMovie8);
		movieList.add(objMovie8);
		
		Movie objMovie9			= new Movie();
		objMovie9.setMovieName("Dhoom");
		objMovie9.setMovieId("MO9");
		objMovie9.setMovieActor("Abhishek Bachchan");
		objMovie9.setMovieCollection(40.00f);
		movieMap.put("MO9", objMovie9);
		movieList.add(objMovie9);
		
		Movie objMovie10			= new Movie();
		objMovie10.setMovieName("Damini");
		objMovie10.setMovieId("MO10");
		objMovie10.setMovieActor("Sunny Deol");
		objMovie10.setMovieCollection(70.00f);
		movieMap.put("MO10", objMovie10);
		movieList.add(objMovie10);
		
		return movieList;
	}
}
