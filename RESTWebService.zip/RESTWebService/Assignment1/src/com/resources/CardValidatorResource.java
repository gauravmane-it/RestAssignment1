package com.resources;

import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/cardValidation")
public class CardValidatorResource {
	
	@GET
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public String checkCard(@MatrixParam("cardNo") String cardNo) {
		String message = "false";
		int iCardNo = 0;
		try {
			 iCardNo = Integer.parseInt(cardNo);
		} catch (Exception e) {
			message = "Please provide proper card number";
			return message;
		}
		message = iCardNo%2 == 0 ? "true" : "false";
		return message;
	}
}
