package com.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.employee.model.Employee;
import com.employee.repository.EmployeeRepository;

@Path("/employee")
public class EmployeeResource {
	
	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("/addEmployee")
	public Employee addEmployee(Employee employee) {
		EmployeeRepository empRepo = new EmployeeRepository();
		int result = empRepo.registerEmployee(employee);
		if(result == 0 || result < 0) {
			new RuntimeException("Please check the request format");
		}
		return employee;
	}
	
	@GET
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("/getAllEmployees")
	public List<Employee> getAllEmployees() {
		List<Employee> empList = null;
		EmployeeRepository empRepo = new EmployeeRepository();
		empList = empRepo.getAllEmployee();
		if(empList == null) {
			new RuntimeException("Please check the request format");
		}
		return empList;
	}
	
	@GET
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("/getEmployeeByLocation")
	public List<Employee> getEmployeeByLocation(@MatrixParam("empLocation") String empLocation) {
		List<Employee> empList = null;
		EmployeeRepository empRepo = new EmployeeRepository();
		empList = empRepo.getEmployeeByLocation(empLocation);
		if(empList == null) {
			new RuntimeException("Epmloyee is not available");
		}
		return empList;
	}
}
