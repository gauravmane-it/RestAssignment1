package com.resources;

import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.dao.StudentDao;
import com.model.Student;

@Path("/student")
public class StudentResource {
	
	@GET
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public List<Student> getStudents() {
		return new StudentDao().getStudents();
	}
	
	@GET
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("{id}")
	public Student getStudentsById(@PathParam("id") String id) {
		return new StudentDao().getStudentsById(id);
	}
	
	@GET
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("/byMark/{mark}")
	public List<Student> getStudentsByMark(@PathParam("mark") float mark) {
		System.out.println(">>>> "+mark);
		return new StudentDao().getGreaterThanMarks(mark);
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("addStudent")
	public Map <String, Student> addStudent(Student student) {
		return new StudentDao().addStudent(student);
	}
	
	@DELETE
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("/deleteStudent/{id}")
	public String deleteStudent(@PathParam("id") String id) {
		return new StudentDao().deleteStudent(id);
	}
	
	@GET
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("/studentByClass/{stdClass}")
	public List<Student> getStudentByClassPathParam(@PathParam("stdClass") String stdClass) {
		return new StudentDao().getStudentByClass(stdClass);
	}
	
	@GET
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("/studentByClassQuery")
	public List<Student> getStudentByClassQueryParam(@QueryParam("stdClass") String stdClass) {
		return new StudentDao().getStudentByClass(stdClass);
	}
	
	@GET
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Path("/studentByClassMatrix")
	public List<Student> getStudentByClassMatrixParam(@MatrixParam("stdClass") String stdClass) {
		return new StudentDao().getStudentByClass(stdClass);
	}
}
