package com.employee.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SQLManager {
	
	public static Connection getConnection() {
		String dbURL = "jdbc:mysql://localhost:3306/springrest";
		String username = "root";
		String password = "gaurav123";
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver"); 
		    conn = DriverManager.getConnection(dbURL, username, password);
		 
		    if (conn != null) {
		        System.out.println("Connected");
		    }
		} catch (SQLException | ClassNotFoundException ex) {
		    ex.printStackTrace();
		  }
		return conn;
	}
}
