package com.employee.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement (name = "employee")
public class Employee {
	String empId;
	String empFirstName;
	String empLastName;
	String empLocation;
	String empBand;
	
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return empLastName;
	}
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}
	public String getEmpLocation() {
		return empLocation;
	}
	public void setEmpLocation(String empLocation) {
		this.empLocation = empLocation;
	}
	public String getEmpBand() {
		return empBand;
	}
	public void setEmpBand(String empBand) {
		this.empBand = empBand;
	}	
}
