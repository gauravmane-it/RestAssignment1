package com.employee.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.employee.db.SQLManager;
import com.employee.model.Employee;

public class EmployeeRepository {
	
	public int registerEmployee(Employee emp) {
		int rowsInserted = 0;
		String sql = "INSERT INTO Employee (empFirstName, empLastName, empLocation, empBand) VALUES (?, ?, ?, ?)";
		Connection conn = SQLManager.getConnection();
		PreparedStatement statement;
		try {
			statement = conn.prepareStatement(sql);
			statement.setString(1, emp.getEmpFirstName());
			statement.setString(2, emp.getEmpLastName());
			statement.setString(3, emp.getEmpLocation());
			statement.setString(4, emp.getEmpBand());
			rowsInserted = statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (rowsInserted > 0) {
		    System.out.println("A new user was inserted successfully!");
		}
		return rowsInserted;
	}
	
	public List<Employee> getAllEmployee() {
		List<Employee> empList = null;
		String selectQuery = "Select * from employee";
		Connection conn = SQLManager.getConnection();
		try {
			Statement stmt  = conn.createStatement();
			ResultSet reSet = stmt.executeQuery(selectQuery);
			if(reSet.next()) {
				empList = new ArrayList<Employee>();
				reSet.beforeFirst();
				while(reSet.next()) {
					Employee emp = new Employee();
					emp.setEmpId(reSet.getString("empId"));
					emp.setEmpFirstName(reSet.getString("empFirstName"));
					emp.setEmpLastName(reSet.getString("empLastName"));
					emp.setEmpLocation(reSet.getString("empLocation"));
					emp.setEmpBand(reSet.getString("empBand"));
					empList.add(emp);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return empList;
	}
	public List<Employee> getEmployeeByLocation(String empLocation) {
		List<Employee> empList = null;
		String selectQuery = "Select * from employee where empLocation = '"+empLocation+"'";
		System.out.println(">> "+selectQuery);
		Connection conn = SQLManager.getConnection();
		try {
			Statement stmt  = conn.createStatement();
			ResultSet reSet = stmt.executeQuery(selectQuery);
			if(reSet.next()) {
				empList = new ArrayList<Employee>();
				reSet.beforeFirst();
				while(reSet.next()) {
					Employee emp = new Employee();
					emp.setEmpId(reSet.getString("empId"));
					emp.setEmpFirstName(reSet.getString("empFirstName"));
					emp.setEmpLastName(reSet.getString("empLastName"));
					emp.setEmpLocation(reSet.getString("empLocation"));
					emp.setEmpBand(reSet.getString("empBand"));
					empList.add(emp);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return empList;
	}
}
