package com.jerseyClient;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class JerseyClient {

	public static void main(String[] args) {
	try {
		//===============================TEXT_XML============================================
		Client client = Client.create();

		WebResource webResource1 = client.resource("http://localhost:8080/JerseyRest/rest/movie/");
		ClientResponse response1 = webResource1.accept("text/xml").get(ClientResponse.class);

		if (response1.getStatus() != 200) {
		   throw new RuntimeException("Failed : HTTP error code : "+ response1.getStatus());
		}

		String output1 = response1.getEntity(String.class);
		System.out.println("===============================TEXT_XML============================================");
		System.out.println("Output from Server TEXT/XML .... \n");
		System.out.println(output1);
		
		//===============================APPLICATION_XML============================================
		
		WebResource webResource2 = client.resource("http://localhost:8080/JerseyRest/rest/movie/inXML");
		ClientResponse response2 = webResource2.accept("application/xml").get(ClientResponse.class);

		if (response2.getStatus() != 200) {
		   throw new RuntimeException("Failed : HTTP error code : "+ response2.getStatus());
		}

		String output2 = response2.getEntity(String.class);
		System.out.println("===============================APPLICATION_XML============================================");
		System.out.println("Output from Server application/xml .... \n");
		System.out.println(output2);
		
		//===============================APPLICATION_JSON============================================
		
		WebResource webResource3 = client.resource("http://localhost:8080/JerseyRest/rest/movie/inJSON");
		ClientResponse response3 = webResource3.accept("application/json").get(ClientResponse.class);

		if (response3.getStatus() != 200) {
		   throw new RuntimeException("Failed : HTTP error code : "+ response3.getStatus());
		}

		String output3 = response3.getEntity(String.class);
		System.out.println("===============================APPLICATION_JSON============================================");
		System.out.println("Output from Server APPLICATION/JSON .... \n");
		System.out.println(output3);
		
		//===============================ByID============================================
		
		WebResource webResource4 = client.resource("http://localhost:8080/JerseyRest/rest/movie/MO1");
		ClientResponse response4 = webResource4.accept("application/xml").get(ClientResponse.class);

		if (response4.getStatus() != 200) {
		   throw new RuntimeException("Failed : HTTP error code : "+ response4.getStatus());
		}

		String output4 = response4.getEntity(String.class);
		System.out.println("===============================ByID============================================");
		System.out.println("Output from Server ByID .... \n");
		System.out.println(output4);
		
		//===============================Deletion============================================
		
		WebResource webResource5 = client.resource("http://localhost:8080/JerseyRest/rest/movie/MO1");
		ClientResponse response5 = webResource5.type("application/xml").delete(ClientResponse.class);

		if (response5.getStatus() != 200) {
		   throw new RuntimeException("Failed : HTTP error code : "+ response5.getStatus());
		}

		String output5 = response5.getEntity(String.class);
		System.out.println("===============================Deletion============================================");
		System.out.println("Output from Server Deletion .... \n");
		System.out.println(output5);
		
	  } catch (Exception e) {
		e.printStackTrace();
	  }

	}
}
