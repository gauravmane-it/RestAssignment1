package com.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement (name = "student")
public class Student implements Comparable<Student>{
	String studentId;
	String studentName;
	String studentClass;
	float StudentTotalMarks;
	
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentClass() {
		return studentClass;
	}
	public void setStudentClass(String studentClass) {
		this.studentClass = studentClass;
	}
	public float getStudentTotalMarks() {
		return StudentTotalMarks;
	}
	public void setStudentTotalMarks(float studentTotalMarks) {
		StudentTotalMarks = studentTotalMarks;
	}
	
	@Override
	public int compareTo(Student o) {
		float mark = ((Student)o).StudentTotalMarks;
		return (int) (this.StudentTotalMarks-mark);
	}
}
